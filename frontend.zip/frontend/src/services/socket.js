export function socketConnection(_) {
  throw new Error("socketConnection not supported anymore. Change to SocketContext");
}